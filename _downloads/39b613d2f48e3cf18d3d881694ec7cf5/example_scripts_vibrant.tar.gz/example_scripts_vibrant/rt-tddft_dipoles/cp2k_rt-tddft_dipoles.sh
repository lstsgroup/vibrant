#!/bin/bash

# ============================================================================
# Script for reading dipole moments from CP2K RT-TDDFT calculations.
#
# The script loops over snapshot directories, extracts dipole moments from
# the RT-TDDFT output files, and appends them to a single XYZ-style file.
# 
# If the user is calculating static resonance Raman and looping over displaced
# structures, then the loop should be adjusted accordingly. See the documentation.
#
# Directory format:
#   structure_X
#
# Example:
#   structure_125/cp2k.out
#
# Output:
#   RTP_dipoles_X.xyz
# ============================================================================

# Number of snapshots
n_snapshots=1 #adjust according to your system

# Output file
dipole_file="RTP_dipoles_X.xyz" 

# Input files
rtp_file="cp2k_example_rt-tddft.out" #adjust according to your system"

for MY_STRUC in $(seq 1 1 ${n_snapshots}); do

  echo ${MY_STRUC} >> "${dipole_file}"
  printf "\n" >> "${dipole_file}"

  cd structure_${MY_STRUC}

  grep "X=" "${rtp_file}" \
    | awk '{ printf "%.0f %-30s %-30s %-30s\n", 1, $2, $4, $6 }' \
    >> ../"${dipole_file}" | while read -r line ; do

    echo "Processing $line"

  done

  cd ..

done
