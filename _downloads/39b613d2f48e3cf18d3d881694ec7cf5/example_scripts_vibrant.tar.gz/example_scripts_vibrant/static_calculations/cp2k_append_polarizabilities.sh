#!/bin/bash

# ============================================================================
# Script for collecting CP2K polarizability data from displaced structure
# directories.
#
# The script loops over all displaced structure directories generated for
# finite-difference calculations and appends the polarizability data
# files into a single output file.
#
# Directory format:
#   system.i_atom_X.i_coord_Y.displ_Z
#
# Example:
#   water.i_atom_0.i_coord_1.displ_0.001
#
# Output:
#   polarizabilities.dat
# ============================================================================

system="water" #adjust according to your system

# Number of atoms and coordinate directions
n_atoms=3 #adjust according to your system
n_dims=3

# Input and output files
polarizability_file="cp2k-raman-1_0.data" #adjust according to your system
output_file="polarizabilities.dat"

# List of displacements
displacements=("0.001" "-0.001") #adjust according to your system

for displ in "${displacements[@]}"; do
  for i in $(seq 0 1 $(($n_atoms-1))); do
    for j in $(seq 0 1 $(($n_dims-1))); do

      cat "${system}.i_atom_${i}.i_coord_${j}.displ_${displ}/${polarizability_file}" >> "${output_file}"

    done
  done
done
