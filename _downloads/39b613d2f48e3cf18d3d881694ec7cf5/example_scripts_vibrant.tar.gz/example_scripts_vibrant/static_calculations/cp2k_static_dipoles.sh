#!/bin/bash

# ============================================================================
# Script for reading dipole moments from CP2K output files.
#
# The script loops over all displaced structure directories generated for
# finite-difference calculations, extracts the dipole moment components from
# cp2k.out, and appends them to a single XYZ-style output file.
#
# Directory format:
#   system.i_atom_X.i_coord_Y.displ_Z
#
# Example:
#   water.i_atom_0.i_coord_1.displ_0.001
#
# Output:
#   dipoles_water.xyz
# ============================================================================

system="water" #adjust according to your system

# Number of atoms and coordinate directions
n_atoms=3 #adjust according to your system
n_dims=3

# Output and input files
dipole_file="dipoles_${system}.xyz"
output_file="cp2k.out" #adjust according to your system

# List of displacements
displacements=("0.001" "-0.001") #adjust according to your system

for displ in "${displacements[@]}"; do
  for i in $(seq 0 1 $(($n_atoms-1))); do
    for j in $(seq 0 1 $(($n_dims-1))); do

      cd ${system}.i_atom_${i}.i_coord_${j}.displ_${displ}

      dip_x=$(grep "X=" "${output_file}" | awk '{print $2}')
      dip_y=$(grep "X=" "${output_file}" | awk '{print $4}')
      dip_z=$(grep "X=" "${output_file}" | awk '{print $6}')

      printf "1\n" >> ../"${dipole_file}"
      printf "\n" >> ../"${dipole_file}"
      printf "%.0f %-30s %-30s %-30s\n" 1 "$dip_x" "$dip_y" "$dip_z" >> ../"${dipole_file}"

      cd ..

    done
  done
done
