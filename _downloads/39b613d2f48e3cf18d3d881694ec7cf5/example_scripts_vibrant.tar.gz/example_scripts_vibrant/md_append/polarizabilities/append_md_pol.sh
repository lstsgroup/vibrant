#!/bin/bash

# ============================================================================
# Script for reading polarizability tensor components from CP2K DFPT output files.
#
# The script loops over snapshot directories, extracts the Cartesian
# polarizability tensor elements from the Raman output files, and writes the
# tensor rows into separate XYZ-style files.
#
# Directory format:
#   structure_X
#
# Example:
#   structure_125/C-raman-1_0.data
#
# Output:
#   alpha_x.xyz
#   alpha_y.xyz
#   alpha_z.xyz
# ============================================================================

# Number of snapshots
n_snapshots=6000 #adjust according to your system

# Input Raman/polarizability file
polarizability_file="C-raman-1_0.data" #adjust according to your system

# Output files
alpha_x_file="alpha_x.xyz"
alpha_y_file="alpha_y.xyz"
alpha_z_file="alpha_z.xyz"

for MY_STRUC in $(seq 1 1 ${n_snapshots}); do

   echo ${MY_STRUC}

   alpha_xx=$(head -n 7 structure_${MY_STRUC}/${polarizability_file} | tail -n 1 | awk '{print $2}')
   alpha_yy=$(head -n 7 structure_${MY_STRUC}/${polarizability_file} | tail -n 1 | awk '{print $3}')
   alpha_zz=$(head -n 7 structure_${MY_STRUC}/${polarizability_file} | tail -n 1 | awk '{print $4}')

   alpha_xy=$(head -n 8 structure_${MY_STRUC}/${polarizability_file} | tail -n 1 | awk '{print $2}')
   alpha_xz=$(head -n 8 structure_${MY_STRUC}/${polarizability_file} | tail -n 1 | awk '{print $3}')
   alpha_yz=$(head -n 8 structure_${MY_STRUC}/${polarizability_file} | tail -n 1 | awk '{print $4}')

   alpha_yx=$(head -n 9 structure_${MY_STRUC}/${polarizability_file} | tail -n 1 | awk '{print $2}')
   alpha_zx=$(head -n 9 structure_${MY_STRUC}/${polarizability_file} | tail -n 1 | awk '{print $3}')
   alpha_zy=$(head -n 9 structure_${MY_STRUC}/${polarizability_file} | tail -n 1 | awk '{print $4}')

   printf "1\n" >> "${alpha_x_file}"
   printf "\n" >> "${alpha_x_file}"

   printf "1\n" >> "${alpha_y_file}"
   printf "\n" >> "${alpha_y_file}"

   printf "1\n" >> "${alpha_z_file}"
   printf "\n" >> "${alpha_z_file}"

   printf "%.0f  %-30s %-30s %-30s\n" 1 "$alpha_xx" "$alpha_xy" "$alpha_xz" >> "${alpha_x_file}"
   printf "%.0f  %-30s %-30s %-30s\n" 1 "$alpha_yx" "$alpha_yy" "$alpha_yz" >> "${alpha_y_file}"
   printf "%.0f  %-30s %-30s %-30s\n" 1 "$alpha_zx" "$alpha_zy" "$alpha_zz" >> "${alpha_z_file}"

done
