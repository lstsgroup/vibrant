#!/bin/bash

# ============================================================================
# Script for reading atomic forces from CP2K output files.
#
# The script loops over all displaced structure directories generated for
# finite-difference calculations, extracts the atomic forces from the CP2K force output file force_cp2k.xyz,
# and appends them to a single output data file.
#
# Directory format:
#   system.i_atom_X.i_coord_Y.displ_Z
#
# Example:
#   water.i_atom_0.i_coord_1.displ_0.001
#
# Output:
#   water-force.dat
# ============================================================================

system="water" #adjust according to your system
force_file="force_cp2k.xyz" #adjust according to your system

# Number of atoms and coordinate directions
n_atoms=3 #adjust according to your system
n_dims=3

# List of displacements
displacements=("0.001" "-0.001") #adjust according to your system

for displ in "${displacements[@]}"; do
  for i in $(seq 0 1 $((n_atoms - 1))); do #atoms
    for j in $(seq 0 1 $((n_dims - 1))); do #dims

      cd ${system}.i_atom_${i}.i_coord_${j}.displ_${displ}
  
      force_xyz=$(grep -P -A ${n_atoms} "#" "${force_file}" | tail -n -${n_atoms} | awk '{print $4 " " $5 " "$6}')

      printf "%-30s" "$force_xyz" >> ../${system}-force.dat
      printf "\n" >> ../${system}-force.dat

      cd ..

    done
  done
done
