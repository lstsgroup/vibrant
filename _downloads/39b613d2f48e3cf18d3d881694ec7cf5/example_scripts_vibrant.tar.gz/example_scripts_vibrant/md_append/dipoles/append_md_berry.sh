#!/bin/bash

# ============================================================================
# Script for reading dipole moments from CP2K output files.
#
# The script loops over snapshot directories, reads the dipole moment
# components from dipole.xyz, and appends them to a single XYZ-style file.
#
# Directory format:
#   structure_X
#
# Example:
#   structure_125/dipole.xyz
#
# Output:
#   dipoles_berry.xyz
# ============================================================================

dipole_file="dipoles_berry.xyz"

# Number of snapshots
n_snapshots=5000 #adjust according to your system

for MY_STRUC in $(seq 1 1 ${n_snapshots}); do

   echo ${MY_STRUC}

   data1=$(sed '1d' structure_${MY_STRUC}/dipole.xyz | awk '{print $5}')
   data2=$(sed '1d' structure_${MY_STRUC}/dipole.xyz | awk '{print $6}')
   data3=$(sed '1d' structure_${MY_STRUC}/dipole.xyz | awk '{print $7}')

   printf "1\n" >> "${dipole_file}"
   printf "\n" >> "${dipole_file}"
   printf "%.0f  %-30s %-30s %-30s\n" 1 "$data1" "$data2" "$data3" >> "${dipole_file}"

done
